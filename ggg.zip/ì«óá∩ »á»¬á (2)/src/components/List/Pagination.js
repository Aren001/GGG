import React from 'react';
import './Pagination.css';

const Pagination = (props) => {

    let {page , totalPages , handlePaginationClick}=props;

    const arrays=[];

    for( page = 1 ; page <= totalPages ; page++){
        arrays.push(page);
    } 

    return (
        <div  style={{display:'flex' , margin:'50px 600px'}}>

            {arrays.map((number ,index) => {

                return <div key={index}  style={{display:'flex', marginLeft:'10px'}}>

                    <button onClick={() =>  handlePaginationClick(number)}  style={{width:'50px' , borderRadius:'80px' , backgroundColor:'#12263D' , color:'white'}} >{number}</button>
                    
                </div>
            })}
        </div>
    )
};
export default Pagination;