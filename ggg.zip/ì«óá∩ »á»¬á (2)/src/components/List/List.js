import React, { useState, useEffect } from 'react';
import { API_URL } from '../../config';
import Loading from '../common/Loading';
import Table from './Table';
import Pagination from './Pagination';
import Select from './Select';



const List = (props) => {
    console.log('list',props)
   
    const {history}=props;
    const [loading, setLoading] = useState(false);
    const [currencies, setCurrencies] = useState([]);
    const [totalPages, setTotalPages] = useState(0);
    const [perPage , setPerPage]=useState(20);
    const [error, setError]= useState('');
    const [page, setPage] = useState(
        props.match.params.id ? +props.match.params.id : 1
    );

    const fetchCurrencies =  () => {
        setLoading(true)
        fetch(`${API_URL}/cryptocurrencies?page=${page}&perPage=${perPage}`)
        .then(resp => {
           // console.log(resp);
            return resp.json()
            .then(data => {
                if(resp.ok){
                    return data;
                }else return Promise.reject(data);
            })
        })
        .then(data => {
           // console.log(data);
            setLoading(false);
            setCurrencies(data.currencies);
            setTotalPages(data.totalPages);



        })
        .catch(err => {
            console.log(err,'EROR');
            setLoading(false);
            setError(err);



        })
                 
    }
    

    const  handlePaginationClick = (nextPage) => { 
        setPage(nextPage);
    }


    const handleChangeSelect = (e) => {
        setPerPage(e.target.value);
    }
    
  








    useEffect(() => {
        fetchCurrencies();
        history.push(`/page/${page}`)
    },[page ,perPage ]);  //zangvacy partadira  fetcha anum pagei het kapvac




    if(loading) {
        return <div className="loading-container"><Loading /></div>
    }
    if(error) {
        return <div className="error">{error}</div>
    }

    return (
        <div>
            <div>
                <Select
                perPage={perPage}
                handleChangeSelect={handleChangeSelect}
                />
            </div>
            <Table currencies={currencies}/>
            <Pagination 
                page={page}
                totalPages={totalPages}
                handlePaginationClick={handlePaginationClick}
            />
        </div>
    )
}

export default List;